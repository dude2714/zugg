# -*- coding: utf-8 -*-
from sys import argv
import json
from apis.torbox_api import TorBoxAPI
from modules import kodi_utils
from modules.source_utils import supported_video_extensions
from modules.utils import clean_file_name, normalize

ls = kodi_utils.local_string
build_url = kodi_utils.build_url
make_listitem = kodi_utils.make_listitem
default_tb_icon = kodi_utils.translate_path('special://home/addons/plugin.video.fenjr/resources/media/cloud.png')
fanart = kodi_utils.translate_path('special://home/addons/plugin.video.fenjr/fanart.png')
folder_str, file_str, down_str = ls(32742).upper(), ls(32743).upper(), ls(32747)
extensions = supported_video_extensions()
TorBox = TorBoxAPI()


def _extract_torrents():
	cloud_data = TorBox.user_cloud()
	if isinstance(cloud_data, dict):
		if isinstance(cloud_data.get('data'), list):
			return cloud_data['data']
		if isinstance(cloud_data.get('torrents'), list):
			return cloud_data['torrents']
	if isinstance(cloud_data, list):
		return cloud_data
	return []


def _extract_files(torrent):
	files = torrent.get('files') or torrent.get('file_list') or []
	if isinstance(files, dict):
		files = files.get('files', [])
	if not isinstance(files, list):
		return []
	return [i for i in files if (i.get('name') or i.get('short_name') or i.get('file_name') or '').lower().endswith(tuple(extensions))]


def tb_torrent_cloud(folder_id=None):
	def _builder():
		for count, item in enumerate(cloud_dict, 1):
			try:
				folder_name = item.get('name') or item.get('torrent_name') or item.get('short_name') or 'TorBox'
				display = '%02d | [B]%s[/B] | [I]%s [/I]' % (count, folder_str, clean_file_name(normalize(folder_name)).upper())
				url_params = {'mode': 'torbox.browse_tb_cloud', 'folder': json.dumps(item)}
				url = build_url(url_params)
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': default_tb_icon, 'poster': default_tb_icon, 'thumb': default_tb_icon, 'fanart': fanart, 'banner': default_tb_icon})
				yield (url, listitem, True)
			except:
				pass

	try:
		cloud_dict = [i for i in _extract_torrents() if _extract_files(i)]
	except:
		cloud_dict = []
	__handle__ = int(argv[1])
	kodi_utils.add_items(__handle__, list(_builder()))
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.premium')


def browse_tb_cloud(folder):
	def _builder():
		for count, item in enumerate(links, 1):
			try:
				cm = []
				torrent_id, file_id = item['torrent_id'], item['file_id']
				url_link = '%s:%s' % (torrent_id, file_id)
				name = clean_file_name(item['name']).upper()
				size = float(item.get('size', 0) or 0)/1073741824
				display = '%02d | [B]%s[/B] | %.2f GB | [I]%s [/I]' % (count, file_str, size, name)
				url_params = {'mode': 'torbox.resolve_tb', 'url': url_link, 'play': 'true'}
				url = build_url(url_params)
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'icon': default_tb_icon, 'poster': default_tb_icon, 'thumb': default_tb_icon, 'fanart': fanart, 'banner': default_tb_icon})
				listitem.setInfo('video', {})
				yield (url, listitem, False)
			except:
				pass

	try:
		torrent = json.loads(folder)
		torrent_id = torrent.get('id') or torrent.get('torrent_id')
		links = []
		for item in _extract_files(torrent):
			name = item.get('name') or item.get('short_name') or item.get('file_name') or ''
			if not name.lower().endswith(tuple(extensions)):
				continue
			file_id = item.get('id') or item.get('file_id') or 0
			size = item.get('size') or item.get('bytes') or 0
			links.append({'torrent_id': torrent_id, 'file_id': file_id, 'name': name, 'size': size})
	except:
		links = []
	__handle__ = int(argv[1])
	kodi_utils.add_items(__handle__, list(_builder()))
	kodi_utils.set_content(__handle__, 'files')
	kodi_utils.end_directory(__handle__)
	kodi_utils.set_view_mode('view.premium')


def resolve_tb(params):
	url = params['url']
	resolved_link = TorBox.unrestrict_link(url)
	if params.get('play', 'false') != 'true':
		return resolved_link
	from modules.player import FenPlayer
	FenPlayer().run(resolved_link, 'video')


def tb_account_info():
	try:
		kodi_utils.show_busy_dialog()
		account_info = TorBox.account_info() or {}
		email = account_info.get('email', '')
		username = account_info.get('username') or account_info.get('name') or account_info.get('id') or ''
		body = []
		append = body.append
		if username:
			append(ls(32755) % username)
		if email:
			append(ls(32756) % email)
		if not body:
			append('TorBox account connected')
		kodi_utils.hide_busy_dialog()
		return kodi_utils.show_text('TORBOX', '\n\n'.join(body), font_size='large')
	except:
		kodi_utils.hide_busy_dialog()
