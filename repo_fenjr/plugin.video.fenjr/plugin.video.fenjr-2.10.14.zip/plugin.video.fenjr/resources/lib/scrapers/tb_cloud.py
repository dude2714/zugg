# -*- coding: utf-8 -*-
from apis.torbox_api import TorBoxAPI
from modules import source_utils
from modules.utils import clean_file_name, normalize
from modules.settings import enabled_debrids_check, filter_by_name

TorBox = TorBoxAPI()
extensions = source_utils.supported_video_extensions()
internal_results, check_title, clean_title = source_utils.internal_results, source_utils.check_title, source_utils.clean_title
get_file_info, release_info_format, seas_ep_filter = source_utils.get_file_info, source_utils.release_info_format, source_utils.seas_ep_filter


class source:
	def __init__(self):
		self.scrape_provider = 'tb_cloud'
		self.sources, self.scrape_results = [], []

	def results(self, info):
		try:
			if not enabled_debrids_check('tb'):
				return internal_results(self.scrape_provider, self.sources)
			title_filter = filter_by_name(self.scrape_provider)
			self.media_type, title = info.get('media_type'), info.get('title')
			self.year, self.season, self.episode = int(info.get('year')), info.get('season'), info.get('episode')
			self.query = clean_title(normalize(title))
			self._scrape_cloud()
			if not self.scrape_results:
				return internal_results(self.scrape_provider, self.sources)
			aliases = source_utils.get_aliases_titles(info.get('aliases', []))

			def _process():
				for item in self.scrape_results:
					try:
						file_name = normalize(item['name'])
						if title_filter and not check_title(title, file_name, aliases, self.year, self.season, self.episode):
							continue
						URLName = clean_file_name(file_name).replace('html', ' ').replace('+', ' ').replace('-', ' ')
						size_bytes = float(item.get('size', 0) or 0)
						size = round(size_bytes/1073741824, 2)
						video_quality, details = get_file_info(name_info=release_info_format(file_name))
						torrent_id, file_id = item['torrent_id'], item['file_id']
						source_item = {'name': file_name, 'title': file_name, 'URLName': URLName, 'quality': video_quality, 'size': size,
									'size_label': '%.2f GB' % size, 'extraInfo': details, 'url_dl': '%s:%s' % (torrent_id, file_id),
									'id': '%s:%s' % (torrent_id, file_id), 'downloads': False, 'direct': True,
									'source': self.scrape_provider, 'scrape_provider': self.scrape_provider}
						yield source_item
					except:
						pass

			self.sources = list(_process())
		except Exception as e:
			from modules.kodi_utils import logger
			logger('FEN torbox scraper Exception', e)
		internal_results(self.scrape_provider, self.sources)
		return self.sources

	def _scrape_cloud(self):
		cloud_files = self._get_cloud_files()
		if not cloud_files:
			return self.sources
		append = self.scrape_results.append
		seen = set()
		for item in cloud_files:
			try:
				normalized = normalize(item['name'])
				item_name = clean_title(normalized)
				if self.query not in item_name:
					continue
				if self.media_type == 'movie':
					if not any(x in normalized for x in self._year_query_list()):
						continue
				elif not seas_ep_filter(self.season, self.episode, normalized):
					continue
				key = '%s:%s' % (item['torrent_id'], item['file_id'])
				if key in seen:
					continue
				seen.add(key)
				append(item)
			except:
				pass

	def _get_cloud_files(self):
		try:
			cloud_data = TorBox.user_cloud()
			torrents = []
			if isinstance(cloud_data, dict):
				if 'data' in cloud_data and isinstance(cloud_data['data'], list):
					torrents = cloud_data['data']
				elif 'torrents' in cloud_data and isinstance(cloud_data['torrents'], list):
					torrents = cloud_data['torrents']
			elif isinstance(cloud_data, list):
				torrents = cloud_data
			results = []
			append = results.append
			for torrent in torrents:
				try:
					torrent_id = torrent.get('id') or torrent.get('torrent_id')
					if not torrent_id:
						continue
					files = torrent.get('files') or torrent.get('file_list') or []
					if isinstance(files, dict):
						files = files.get('files', [])
					if not isinstance(files, list):
						continue
					for file_item in files:
						name = file_item.get('name') or file_item.get('short_name') or file_item.get('file_name') or ''
						if not name.lower().endswith(tuple(extensions)):
							continue
						file_id = file_item.get('id') or file_item.get('file_id') or 0
						size = file_item.get('size') or file_item.get('bytes') or 0
						append({'torrent_id': torrent_id, 'file_id': file_id, 'name': name, 'size': size})
				except:
					pass
			return results
		except:
			return []

	def _year_query_list(self):
		return (str(self.year), str(self.year+1), str(self.year-1))
