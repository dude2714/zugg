import base64


class _QRCodeCompat(object):
    def __init__(self, data):
        self._data = data

    def png(self, path, scale=4.4):
        # ResolveURL only needs an image path for its auth dialog.
        # The verification URL and code are shown as text, so a tiny valid PNG
        # keeps the flow working without adding extra imaging dependencies.
        pixel_png = (
            b'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8'
            b'/w8AAgMBgN0Xl1sAAAAASUVORK5CYII='
        )
        with open(path, 'wb') as image_file:
            image_file.write(base64.b64decode(pixel_png))
        return path


def create(data, *args, **kwargs):
    return _QRCodeCompat(data)