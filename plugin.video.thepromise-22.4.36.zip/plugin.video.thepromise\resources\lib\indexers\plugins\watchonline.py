# -*- coding: utf-8 -*-

"""
    ThePromise Add-on
    Isolated 24/7 TV entrypoint (kept separate from normal TV scrapers).
"""

import os
import sys

from resources.lib.modules import control


class Indexer:
    def root(self):
        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        art_path = control.artPath()
        addon_fanart = control.addonFanart()

        items = [
            ('24 / 7 TV Shows', 'watchonline_channels', 'channels.png', 'DefaultTVShows.png')
        ]

        for label, action, thumb_name, default_icon in items:
            thumb = os.path.join(art_path, thumb_name) if art_path else default_icon
            url = '%s?action=%s' % (sysaddon, action)
            try:
                li = control.item(label=label, offscreen=True)
            except:
                li = control.item(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb, 'fanart': addon_fanart})
            li.setInfo(type='video', infoLabels={'plot': '[CR]'})
            control.addItem(handle=syshandle, url=url, listitem=li, isFolder=True)

        control.content(syshandle, '')
        control.directory(syshandle, cacheToDisc=True)
