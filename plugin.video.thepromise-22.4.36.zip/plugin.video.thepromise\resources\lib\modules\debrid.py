import time

# -*- coding: utf-8 -*-

"""
    Covenant Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""


try:
    import resolveurl

    debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()]

    if len(debrid_resolvers) == 0:
        # Support Rapidgator accounts! Unfortunately, `sources.py` assumes that rapidgator.net is only ever
        # accessed via a debrid service, so we add rapidgator as a debrid resolver and everything just works.
        # As a bonus(?), rapidgator links will be highlighted just like actual debrid links
        debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True, include_universal=False) if 'rapidgator.net' in resolver.domains]

except:
    debrid_resolvers = []

try:
    from kodi_six import xbmc
except:
    xbmc = None


_resolver_failures = {}
_resolver_backoff_until = {}


def _resolver_available(name):
    return _resolver_backoff_until.get(name, 0) <= time.time()


def _resolver_mark_failure(name):
    count = _resolver_failures.get(name, 0) + 1
    _resolver_failures[name] = count
    if count >= 2:
        _resolver_backoff_until[name] = time.time() + 90


def _resolver_mark_success(name):
    _resolver_failures[name] = 0
    _resolver_backoff_until[name] = 0


def _should_backoff(name, message):
    message = (message or '').lower()
    if name == 'Real-Debrid' and '403' in message:
        return True
    return any(code in message for code in ('429', '500', '502', '503', '504'))


def status():
    return debrid_resolvers != []


def _klog(message):
    try:
        if xbmc:
            xbmc.log('[ThePromise-Debrid] %s' % message, xbmc.LOGINFO)
    except:
        pass


def resolver(url, debrid, from_pack=None, return_list=False):
    try:
        ordered = [r for r in debrid_resolvers if r.name == debrid] + [r for r in debrid_resolvers if r.name != debrid]
        for debrid_resolver in ordered:
            if not _resolver_available(debrid_resolver.name):
                continue
            try:
                debrid_resolver.login()

                if from_pack:
                    _host, _media_id = debrid_resolver.get_host_and_id(url)
                    url_list = debrid_resolver.get_media_url(_host, _media_id, return_all=True)
                    if return_list:
                        return url_list
                    season, episode = from_pack.split('_')
                    url = [s['link'] for s in url_list if matchEpisode(s['name'], season, episode)][0]

                _host, _media_id = debrid_resolver.get_host_and_id(url)
                stream_url = debrid_resolver.get_media_url(_host, _media_id)
                if stream_url:
                    _resolver_mark_success(debrid_resolver.name)
                    _klog('resolved via %s' % debrid_resolver.name)
                    return stream_url
            except Exception as e:
                msg = str(e)
                if _should_backoff(debrid_resolver.name, msg):
                    _resolver_mark_failure(debrid_resolver.name)
                    if debrid_resolver.name == 'Real-Debrid' and '403' in msg:
                        _resolver_backoff_until[debrid_resolver.name] = time.time() + 600
                else:
                    _resolver_mark_success(debrid_resolver.name)
                _klog('resolver fail %s: %s' % (debrid_resolver.name, msg))
                continue
        _klog('all resolvers failed for requested debrid: %s' % debrid)
        return None
    except:
        from resources.lib.modules import log_utils
        log_utils.log('%s Resolve Failure' % debrid, 1)
        return None


def matchEpisode(filename, season, episode):
    import re
    filename = re.sub('[^A-Za-z0-9 ]+', ' ', filename.split('/')[-1]).lower()
    r = r"(?:[a-z\s*]|^)(?:%s|%s)\s*(?:e|x|episode)\s*(?:%s|%s)\s+" % (season.zfill(2), season, episode.zfill(2), episode)
    m = re.search(r, filename, flags=re.S)

    if m:
        return True


