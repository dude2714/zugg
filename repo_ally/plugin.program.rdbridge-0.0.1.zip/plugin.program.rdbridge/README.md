# Ally (MVP)

Queue a magnet through multiple debrid services (failover), then hand off the playable URL.

Addon id: `plugin.program.rdbridge`

## Installed Zip

- `plugin.program.rdbridge-0.0.1.zip`

Copied to Kodi packages:

- `C:\Users\johns\AppData\Roaming\Kodi\addons\packages\plugin.program.rdbridge-0.0.1.zip`

## Quick Start (Kodi)

1. Install from zip file -> `plugin.program.rdbridge-0.0.1.zip`
2. Run addon directly to open quick menu.
3. Choose one:
   - Queue from clipboard magnet
   - Paste magnet manually
   - List available debrid services

## RunPlugin Examples

- `RunPlugin(plugin://plugin.program.rdbridge/?action=queue_from_clipboard)`
- `RunPlugin(plugin://plugin.program.rdbridge/?action=queue_from_input)`
- `RunPlugin(plugin://plugin.program.rdbridge/?action=list_services)`
- `RunPlugin(plugin://plugin.program.rdbridge/?action=queue_magnet&magnet=<urlencoded_magnet>)`

Optional service order override per call:

- `&services=Real-Debrid,AllDebrid,Premiumize.me,Debrid-Link.fr,TorBox,Linksnappy,MegaDebrid`

## Notes

- TorBox support is enabled in bridge ordering and aliases.
- TorBox will only be used when a TorBox universal resolver exists in ResolveURL.
- 429 and 451 responses come from debrid APIs, not from this bridge addon.
