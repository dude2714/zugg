# -*- coding: utf-8 -*-

import json
import re
import sys
from urllib.parse import parse_qsl, quote_plus

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

PREFERRED_SERVICES = [
    'Real-Debrid',
    'AllDebrid',
    'Premiumize.me',
    'Debrid-Link.fr',
    'TorBox',
    'Linksnappy',
    'MegaDebrid',
]


def normalize_name(text):
    value = (text or '').lower()
    for ch in (' ', '-', '.', '_'):
        value = value.replace(ch, '')
    return value


def log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGINFO)


def params():
    if len(sys.argv) < 3:
        return {}
    return dict(parse_qsl(sys.argv[2].replace('?', '')))


def show(msg, title='Ally'):
    xbmcgui.Dialog().ok(title, msg)


def get_clipboard_text():
    try:
        if hasattr(xbmc, 'getClipboard'):
            return (xbmc.getClipboard() or '').strip()
    except Exception:
        pass
    return ''


def looks_like_magnet(value):
    return bool(value and value.lower().startswith('magnet:?'))


def setting_int(name, default_value):
    try:
        return max(1, int(ADDON.getSetting(name) or default_value))
    except Exception:
        return default_value


def extract_code(err_text):
    match = re.search(r'\((\d{3})\)\s*$', err_text or '')
    return match.group(1) if match else ''


def get_universal_resolvers():
    try:
        import resolveurl
        resolver_defs = resolveurl.relevant_resolvers(order_matters=True)
        return [resolver() for resolver in resolver_defs if resolver.isUniversal()]
    except Exception as e:
        log('Failed to load ResolveURL universal resolvers: %s' % e)
        return []


def normalize_service_list(csv_services):
    if csv_services:
        services = [s.strip() for s in csv_services.split(',') if s.strip()]
        return services

    configured = (ADDON.getSetting('service_order') or '').strip()
    if configured:
        services = [s.strip() for s in configured.split(',') if s.strip()]
        if services:
            return services

    return PREFERRED_SERVICES[:]


def select_resolvers(all_resolvers, requested_services, max_services):
    by_lower_name = dict((r.name.lower(), r) for r in all_resolvers)
    by_normalized_name = dict((normalize_name(r.name), r) for r in all_resolvers)

    aliases = {
        'realdebrid': 'realdebrid',
        'alldebrid': 'alldebrid',
        'premiumize': 'premiumizeme',
        'premiumizeme': 'premiumizeme',
        'debridlink': 'debridlinkfr',
        'debridlinkfr': 'debridlinkfr',
        'torbox': 'torbox',
        'linksnappy': 'linksnappy',
        'megadebrid': 'megadebrid',
    }

    selected = []
    for service_name in requested_services:
        resolver = by_lower_name.get(service_name.lower())
        if not resolver:
            normalized_request = normalize_name(service_name)
            normalized_request = aliases.get(normalized_request, normalized_request)
            resolver = by_normalized_name.get(normalized_request)
        if resolver and resolver not in selected:
            selected.append(resolver)
        if len(selected) >= max_services:
            break

    if len(selected) < max_services:
        for resolver in all_resolvers:
            if resolver not in selected:
                selected.append(resolver)
            if len(selected) >= max_services:
                break

    return selected[:max_services]


def resolve_with_service(resolver, magnet, retry_delay):
    service_name = resolver.name
    try:
        resolver.login()
    except Exception as e:
        return None, '%s login failed: %s' % (service_name, e), ''

    attempts = 2
    for attempt in range(1, attempts + 1):
        try:
            host, media_id = resolver.get_host_and_id(magnet)
            stream_url = resolver.get_media_url(host, media_id)
            if stream_url:
                return stream_url, '', ''
            return None, '%s returned empty stream URL' % service_name, ''
        except Exception as e:
            err_text = str(e)
            err_code = extract_code(err_text)
            log('%s attempt %d failed: %s' % (service_name, attempt, err_text))

            if attempt < attempts and err_code in ('429', '500', '502', '503', '504'):
                xbmc.sleep(retry_delay * 1000)
                continue

            return None, '%s: %s' % (service_name, err_text), err_code

    return None, '%s exhausted retries' % service_name, ''


def handoff_stream(stream_url, data):
    mode = (data.get('handoff_mode') or ADDON.getSetting('handoff_mode') or 'play_direct').strip()
    target_addon = (data.get('target_addon') or ADDON.getSetting('default_target_addon') or 'plugin.video.thepromise').strip()

    if mode == 'runplugin_callback':
        callback = (data.get('callback') or '').strip()
        if callback:
            cmd = callback.replace('{url}', quote_plus(stream_url))
            xbmc.executebuiltin('RunPlugin(%s)' % cmd)
            return

        xbmc.executebuiltin('RunPlugin(plugin://%s/?action=play_url&url=%s)' % (target_addon, quote_plus(stream_url)))
        return

    list_item = xbmcgui.ListItem(path=stream_url)
    xbmc.Player().play(stream_url, list_item)


def queue_magnet(data):
    magnet = data.get('magnet', '').strip()
    if not magnet:
        show('Missing magnet parameter.')
        return

    all_resolvers = get_universal_resolvers()
    if not all_resolvers:
        show('No universal debrid resolvers found in ResolveURL.')
        return

    requested_services = normalize_service_list(data.get('services', ''))
    max_services = min(7, setting_int('max_services', 7))
    retry_delay = setting_int('retry_delay_seconds', 8)

    chosen_resolvers = select_resolvers(all_resolvers, requested_services, max_services)
    if not chosen_resolvers:
        show('No matching debrid resolvers were selected.')
        return

    errors = []
    progress = xbmcgui.DialogProgress()
    progress.create('Ally', 'Trying up to %d debrid services...' % len(chosen_resolvers))

    try:
        for index, resolver in enumerate(chosen_resolvers, start=1):
            if progress.iscanceled():
                return

            service_name = resolver.name
            percent = int((float(index - 1) / float(len(chosen_resolvers))) * 100)
            progress.update(percent, 'Trying %s (%d/%d)' % (service_name, index, len(chosen_resolvers)))

            stream_url, err, err_code = resolve_with_service(resolver, magnet, retry_delay)
            if stream_url:
                progress.update(100, 'Resolved with %s' % service_name)
                handoff_stream(stream_url, data)
                return

            if err:
                errors.append(err)

            if err_code == '451':
                # Legal block often persists across services for same hash. Bail fast.
                break
    finally:
        progress.close()

    if not errors:
        show('No stream resolved from selected debrid services.')
        return

    show('Failed to resolve magnet.\n\n%s' % '\n'.join(errors[:6]))


def queue_from_input(data):
    keyboard = xbmc.Keyboard('', 'Paste magnet URL')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return

    magnet = (keyboard.getText() or '').strip()
    if not looks_like_magnet(magnet):
        show('Input is not a valid magnet URL.')
        return

    next_data = dict(data.items())
    next_data['magnet'] = magnet
    queue_magnet(next_data)


def queue_from_clipboard(data):
    magnet = get_clipboard_text()
    if not looks_like_magnet(magnet):
        show('Clipboard does not contain a magnet URL.')
        return

    next_data = dict(data.items())
    next_data['magnet'] = magnet
    queue_magnet(next_data)


def quick_menu(data):
    options = [
        'Queue from clipboard magnet',
        'Paste magnet manually',
        'List available debrid services',
        'Show help',
    ]
    idx = xbmcgui.Dialog().select('Ally', options)
    if idx == 0:
        queue_from_clipboard(data)
        return
    if idx == 1:
        queue_from_input(data)
        return
    if idx == 2:
        list_services()
        return
    if idx == 3:
        route('help', data)
        return


def list_services():
    all_resolvers = get_universal_resolvers()
    if not all_resolvers:
        show('No universal debrid resolvers found.')
        return
    names = [resolver.name for resolver in all_resolvers]
    show('Available universal resolvers:\n\n%s' % '\n'.join(names))


def route(action, data):
    if action == 'ping':
        show('Ally is installed and routing actions.')
        return

    if action == 'list_services':
        list_services()
        return

    if action == 'queue_magnet':
        queue_magnet(data)
        return

    if action == 'queue_from_input':
        queue_from_input(data)
        return

    if action == 'queue_from_clipboard':
        queue_from_clipboard(data)
        return

    if action == 'help' or not action:
        if not action:
            quick_menu(data)
            return
        show(
            'Ally is ready.\n\n'
            'Try:\n'
            'RunPlugin(plugin://%s/?action=queue_from_clipboard)\n'
            'RunPlugin(plugin://%s/?action=queue_from_input)\n'
            'RunPlugin(plugin://%s/?action=list_services)\n'
            'RunPlugin(plugin://%s/?action=queue_magnet&magnet=<urlencoded_magnet>)\n\n'
            'Optional:\n'
            '&services=Real-Debrid,AllDebrid,Premiumize.me,Debrid-Link.fr,TorBox,Linksnappy,MegaDebrid\n'
            '&handoff_mode=play_direct|runplugin_callback' % (ADDON_ID, ADDON_ID, ADDON_ID, ADDON_ID)
        )
        return

    show('Unknown action: %s' % action)


if __name__ == '__main__':
    data = params()
    route(data.get('action', ''), data)
