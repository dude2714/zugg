# -*- coding: utf-8 -*-
from datetime import datetime
from apis.torbox_api import TorBoxAPI
from modules import kodi_utils
from modules.source_utils import supported_video_extensions
from modules.utils import clean_file_name, normalize

# logger = kodi_utils.logger
ls, sys, make_listitem, build_url = kodi_utils.local_string, kodi_utils.sys, kodi_utils.make_listitem, kodi_utils.build_url
add_items, set_content, end_directory = kodi_utils.add_items, kodi_utils.set_content, kodi_utils.end_directory
show_busy_dialog, hide_busy_dialog, show_text, set_view_mode = kodi_utils.show_busy_dialog, kodi_utils.hide_busy_dialog, kodi_utils.show_text, kodi_utils.set_view_mode
json = kodi_utils.json
default_tb_icon, fanart = kodi_utils.get_icon('premiumize'), kodi_utils.addon_fanart
file_str, down_str = ls(32743).upper(), '[B]%s[/B]' % ls(32747)
extensions = supported_video_extensions()
TorBox = TorBoxAPI()


def _iter_cloud_files():
	cloud = TorBox.user_cloud()
	items = []
	if isinstance(cloud, dict):
		if isinstance(cloud.get('data'), list):
			items = cloud['data']
		elif isinstance(cloud.get('results'), list):
			items = cloud['results']
	elif isinstance(cloud, list):
		items = cloud
	for item in items:
		torrent_id = item.get('id')
		for entry in item.get('files', []):
			name = entry.get('short_name') or entry.get('name') or ''
			if not name.lower().endswith(tuple(extensions)):
				continue
			size = float(int(entry.get('size', 0) or 0)) / 1073741824
			link = '%s:%s' % (torrent_id, entry.get('id', 0))
			yield {'name': name, 'size': size, 'link': link}


def tb_torrent_cloud():
	def _builder():
		for count, item in enumerate(cloud_files, 1):
			try:
				cm = []
				name = clean_file_name(normalize(item['name'])).upper()
				display = '%02d | [B]%s[/B] | %.2f GB | [I]%s [/I]' % (count, file_str, item['size'], name)
				url_params = {'mode': 'torbox.resolve_tb', 'url': item['link'], 'play': 'true'}
				down_file_params = {'mode': 'downloader', 'name': name, 'url': item['link'], 'action': 'cloud.torbox', 'image': default_tb_icon}
				cm.append((down_str, 'RunPlugin(%s)' % build_url(down_file_params)))
				url = build_url(url_params)
				listitem = make_listitem()
				listitem.setLabel(display)
				listitem.addContextMenuItems(cm)
				listitem.setArt({'icon': default_tb_icon, 'poster': default_tb_icon, 'thumb': default_tb_icon, 'fanart': fanart, 'banner': default_tb_icon})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot(' ')
				yield (url, listitem, False)
			except:
				pass
	try:
		cloud_files = sorted(list(_iter_cloud_files()), key=lambda k: k['name'])
	except:
		cloud_files = []
	handle = int(sys.argv[1])
	add_items(handle, list(_builder()))
	set_content(handle, 'files')
	end_directory(handle, False)
	set_view_mode('view.premium')


def resolve_tb(params):
	url = params['url']
	resolved_link = TorBox.unrestrict_link(url)
	if params.get('play', 'false') != 'true':
		return resolved_link
	from modules.player import FenPlayer
	FenPlayer().run(resolved_link, 'video')


def tb_account_info():
	try:
		show_busy_dialog()
		account_info = TorBox.account_info()
		email = account_info.get('email') or account_info.get('username') or account_info.get('auth_id') or account_info.get('id')
		status = 'Premium' if account_info.get('premium') or account_info.get('is_premium') else 'Active'
		expires = account_info.get('premium_expires_at') or account_info.get('expires_at')
		body = []
		append = body.append
		append(ls(32755) % email)
		append(ls(32757) % status)
		if expires:
			try:
				expires_dt = datetime.fromisoformat(str(expires).replace('Z', '+00:00')).replace(tzinfo=None)
				days_remaining = (expires_dt - datetime.today()).days
				append(ls(32750) % expires_dt)
				append(ls(32751) % days_remaining)
			except:
				pass
		hide_busy_dialog()
		return show_text('TORBOX', '\n\n'.join(body), font_size='large')
	except:
		hide_busy_dialog()


def active_days():
	try:
		account_info = TorBox.account_info()
		expires = account_info.get('premium_expires_at') or account_info.get('expires_at')
		if expires:
			expires_dt = datetime.fromisoformat(str(expires).replace('Z', '+00:00')).replace(tzinfo=None)
			return (expires_dt - datetime.today()).days
	except:
		pass
	return 0
