# -*- coding: utf-8 -*-
import re
from caches.main_cache import cache_object
from modules import kodi_utils
from modules.utils import copy2clip

# logger = kodi_utils.logger
requests, sleep, monitor = kodi_utils.requests, kodi_utils.sleep, kodi_utils.monitor
show_busy_dialog, hide_busy_dialog = kodi_utils.show_busy_dialog, kodi_utils.hide_busy_dialog
progress_dialog, ok_dialog, confirm_dialog = kodi_utils.progress_dialog, kodi_utils.ok_dialog, kodi_utils.confirm_dialog
notification, get_icon, ls = kodi_utils.notification, kodi_utils.get_icon, kodi_utils.local_string
get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting
path_exists, maincache_db = kodi_utils.path_exists, kodi_utils.maincache_db
database, clear_property = kodi_utils.database, kodi_utils.clear_property
manage_settings_reset = kodi_utils.manage_settings_reset
logger = kodi_utils.logger

base_url = 'https://api.torbox.app/v1/api/'
timeout = 20.0
icon = get_icon('premiumize')


class TorBoxAPI:
	def __init__(self):
		self.token = get_setting('fen.tb.token') or get_setting('fen.tb.api_key')
		self.break_auth_loop = False

	def _headers(self):
		if not self.token:
			return {}
		return {'Authorization': 'Bearer %s' % self.token}

	def _get(self, endpoint, params=None, auth=True):
		result = None
		try:
			if auth and not self.token:
				return None
			url = base_url + endpoint
			headers = self._headers() if auth else None
			result = requests.get(url, params=params or {}, headers=headers, timeout=timeout).json()
		except:
			pass
		return result

	def _post(self, endpoint, data=None, params=None, json_data=None, auth=True):
		result = None
		try:
			if auth and not self.token:
				return None
			url = base_url + endpoint
			headers = self._headers() if auth else None
			request_kwargs = {'params': params or {}, 'headers': headers, 'timeout': timeout}
			if json_data is not None:
				request_kwargs['json'] = json_data
			else:
				request_kwargs['data'] = data or {}
			result = requests.post(url, **request_kwargs).json()
		except:
			pass
		return result

	def _parse_data(self, response):
		if not response:
			return None
		if isinstance(response, dict):
			if response.get('data') is not None:
				return response['data']
			if response.get('results') is not None:
				return response['results']
		return response

	def auth(self):
		self.token = ''
		response = self._get('user/auth/device/start', params={'app': 'Fen Fork Kodi'}, auth=False)
		data = self._parse_data(response)
		if not data:
			return ok_dialog(text=32574)
		verify_url = data.get('verification_url') or data.get('verification_uri') or data.get('url') or 'https://torbox.app/device'
		user_code = data.get('user_code') or data.get('code') or ''
		device_code = data.get('device_code')
		if not device_code:
			return ok_dialog(text=32574)
		try:
			copy2clip(user_code)
		except:
			pass
		line = '%s[CR]%s[CR]%s'
		content = line % (ls(32517), ls(32700) % verify_url, ls(32701) % '[COLOR steelblue]%s[/COLOR]' % user_code)
		progressDialog = progress_dialog('%s TorBox' % ls(32057), icon)
		progressDialog.update(content, 0)
		while not progressDialog.iscanceled() and not self.token:
			if self.break_auth_loop:
				break
			sleep(5000)
			response = self._post('user/auth/device/token', data={'device_code': device_code}, auth=False)
			if not response:
				continue
			data = self._parse_data(response)
			if not data:
				if response.get('detail') in ('not_authorized', 'authorization_pending'):
					continue
				if response.get('error'):
					break
				continue
			token = data.get('token') or data.get('access_token') or data.get('api_key') or data.get('apikey')
			if token:
				self.token = str(token)
				manage_settings_reset()
				set_setting('tb.token', self.token)
				set_setting('tb.api_key', self.token)
				set_setting('tb.enabled', 'true')
				manage_settings_reset(True)
				break
		try:
			progressDialog.close()
		except:
			pass
		if self.token:
			account = self.account_info()
			account_id = account.get('email') or account.get('username') or account.get('auth_id') or account.get('id')
			if account_id:
				manage_settings_reset()
				set_setting('tb.account_id', str(account_id))
				manage_settings_reset(True)
			ok_dialog(text=32576)

	def revoke(self):
		manage_settings_reset()
		set_setting('tb.token', '')
		set_setting('tb.api_key', '')
		set_setting('tb.account_id', '')
		set_setting('tb.enabled', 'false')
		notification('TorBox Authorization Reset', 3000)
		manage_settings_reset(True)

	def account_info(self):
		response = self._get('user/me')
		result = self._parse_data(response)
		if isinstance(result, dict):
			return result
		return {}

	def check_cache(self, hashes):
		response = self._post('torrents/checkcached', params={'format': 'list'}, json_data={'hashes': hashes})
		result = self._parse_data(response)
		if isinstance(result, dict):
			return result
		if isinstance(result, list):
			return {'cached': result}
		return {'cached': []}

	def _extract_cached_hashes(self, cache_response):
		if not cache_response:
			return []
		cached = cache_response.get('cached') if isinstance(cache_response, dict) else cache_response
		if isinstance(cached, dict):
			if all(isinstance(v, (bool, int)) for v in cached.values()):
				cached = [k for k, v in cached.items() if bool(v)]
			else:
				cached = list(cached.keys())
		if not isinstance(cached, list):
			return []
		normalized = []
		for item in cached:
			if isinstance(item, str):
				normalized.append(item.lower())
			elif isinstance(item, dict):
				item_hash = item.get('hash') or item.get('info_hash') or item.get('btih')
				if isinstance(item_hash, str):
					normalized.append(item_hash.lower())
		return normalized

	def user_cloud(self):
		url = 'torrents/mylist'
		string = 'fen_tb_user_cloud'
		return cache_object(self._get, string, url, False, 0.5)

	def list_transfer(self, transfer_id):
		response = self._get('torrents/mylist', params={'id': transfer_id, 'limit': 1})
		data = self._parse_data(response)
		if isinstance(data, list) and data:
			return data[0]
		if isinstance(data, dict):
			if 'torrents' in data and data['torrents']:
				return data['torrents'][0]
			return data
		return {}

	def _request_download(self, torrent_id, file_id=0):
		try:
			user_ip = requests.get('https://api.ipify.org', timeout=2.0).text
		except:
			user_ip = ''
		params = {'token': self.token, 'torrent_id': int(torrent_id), 'file_id': int(file_id or 0)}
		if user_ip:
			params['user_ip'] = user_ip
		response = self._get('torrents/requestdl', params=params, auth=False)
		data = self._parse_data(response)
		if isinstance(data, str) and data.startswith('http'):
			return data
		if isinstance(data, dict):
			for key in ('download_url', 'download', 'url', 'link'):
				value = data.get(key)
				if isinstance(value, str) and value.startswith('http'):
					return value
		if isinstance(response, str) and response.startswith('http'):
			return response
		if isinstance(response, dict):
			for key in ('download_url', 'download', 'url', 'link'):
				value = response.get(key)
				if isinstance(value, str) and value.startswith('http'):
					return value
			inner = response.get('data')
			if isinstance(inner, str) and inner.startswith('http'):
				return inner
		return None

	def unrestrict_link(self, link):
		if isinstance(link, str) and link.startswith('http'):
			return link
		try:
			parts = str(link).split(':')
			if len(parts) == 2:
				torrent_id, file_id = parts
				return self._request_download(torrent_id, file_id)
		except:
			pass
		return None

	def create_transfer(self, magnet):
		response = self._post('torrents/createtorrent', data={'magnet': magnet, 'seed': 3, 'allow_zip': 'false'})
		data = self._parse_data(response)
		if isinstance(data, dict):
			for key in ('torrent_id', 'id'):
				if key in data:
					return data[key]
		if isinstance(data, list) and data:
			item = data[0]
			if isinstance(item, dict):
				return item.get('torrent_id') or item.get('id')
		logger('FEN TORBOX', 'create_transfer response=%s' % str(response)[:300])
		return ''

	def delete_transfer(self, transfer_id):
		response = self._post('torrents/controltorrent', data={'operation': 'delete', 'torrent_id': int(transfer_id)})
		if isinstance(response, dict):
			return response.get('success', False)
		return False

	def _video_file(self, item):
		from modules.source_utils import supported_video_extensions
		extensions = supported_video_extensions()
		name = item.get('name') or item.get('short_name') or item.get('file_name') or item.get('filename') or ''
		name = name.lower()
		if not name:
			return False
		return any(name.endswith(ext) for ext in extensions)

	def _file_name(self, item):
		return item.get('name') or item.get('short_name') or item.get('file_name') or item.get('filename') or ''

	def _file_list(self, transfer_info):
		files = transfer_info.get('files') or transfer_info.get('file_list') or []
		if isinstance(files, dict):
			files = files.get('files', [])
		if not isinstance(files, list):
			files = []
		return files

	def _wait_for_files(self, transfer_id, attempts=8, delay_ms=1200):
		transfer_info = {}
		for count in range(1, attempts + 1):
			transfer_info = self.list_transfer(transfer_id) or {}
			files = [i for i in self._file_list(transfer_info) if self._video_file(i)]
			if files:
				logger('FEN TORBOX', 'files ready transfer_id=%s attempt=%s file_count=%s' % (transfer_id, count, len(files)))
				return transfer_info, files
			state = transfer_info.get('download_state') or transfer_info.get('state') or transfer_info.get('status') or 'unknown'
			logger('FEN TORBOX', 'waiting for files transfer_id=%s attempt=%s state=%s' % (transfer_id, count, state))
			sleep(delay_ms)
		return transfer_info, []

	def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, title, season, episode):
		from modules.source_utils import seas_ep_filter, EXTRAS
		try:
			transfer_id = self.create_transfer(magnet_url)
			if not transfer_id:
				logger('FEN TORBOX', 'create_transfer failed')
				return None
			transfer_info, files = self._wait_for_files(transfer_id)
			if not files:
				logger('FEN TORBOX', 'no video files transfer_id=%s state=%s' % (transfer_id, transfer_info.get('download_state') or transfer_info.get('state') or transfer_info.get('status') or 'unknown'))
				if not store_to_cloud:
					self.delete_transfer(transfer_id)
				return None
			chosen = None
			if season:
				episode_title = re.sub(r'[^A-Za-z0-9-]+', '.', title.replace("'", '').replace('&', 'and').replace('%', '.percent')).lower()
				matched = [i for i in files if seas_ep_filter(season, episode, self._file_name(i))]
				if matched:
					extras = [i for i in EXTRAS if not i == title.lower()]
					for item in matched:
						compare = seas_ep_filter(season, episode, self._file_name(item), split=True)
						compare = re.sub(episode_title, '', compare)
						if not any(x in compare for x in extras):
							chosen = item
							break
				if not chosen and matched:
					chosen = matched[0]
			else:
				chosen = max(files, key=lambda x: float(x.get('size', 0) or 0))
			if not chosen:
				logger('FEN TORBOX', 'no chosen file transfer_id=%s season=%s episode=%s file_count=%s' % (transfer_id, season, episode, len(files)))
				if not store_to_cloud:
					self.delete_transfer(transfer_id)
				return None
			file_id = chosen.get('id') or chosen.get('file_id') or 0
			file_url = self._request_download(transfer_id, file_id)
			logger('FEN TORBOX', 'requestdl transfer_id=%s file_id=%s success=%s file=%s' % (transfer_id, file_id, bool(file_url), self._file_name(chosen)))
			if not store_to_cloud:
				self.delete_transfer(transfer_id)
			return file_url
		except Exception as e:
			logger('FEN TORBOX', 'resolve_magnet exception %s' % str(e))
			try:
				if transfer_id:
					self.delete_transfer(transfer_id)
			except:
				pass
			return None

	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			transfer_id = self.create_transfer(magnet_url)
			if not transfer_id:
				return None
			transfer_info = self.list_transfer(transfer_id)
			results = []
			append = results.append
			for item in self._file_list(transfer_info):
				if self._video_file(item):
					file_id = item.get('id') or item.get('file_id') or 0
					append({'link': '%s:%s' % (transfer_id, file_id), 'filename': item.get('name', ''), 'size': item.get('size', 0)})
			self.delete_transfer(transfer_id)
			return results
		except:
			try:
				if transfer_id:
					self.delete_transfer(transfer_id)
			except:
				pass
			return None

	def add_uncached_torrent(self, magnet_url, pack=False):
		def _return_failed(message=32574, cancelled=False):
			try:
				progressDialog.close()
			except Exception:
				pass
			hide_busy_dialog()
			sleep(500)
			if cancelled:
				if confirm_dialog(text=32044): ok_dialog(heading=32733, text=ls(32732) % 'TorBox')
				else: self.delete_transfer(transfer_id)
			else: ok_dialog(heading=32733, text=message)
			return False
		show_busy_dialog()
		transfer_id = self.create_transfer(magnet_url)
		if not transfer_id:
			return _return_failed()
		transfer_info = self.list_transfer(transfer_id)
		if not transfer_info:
			return _return_failed()
		if pack:
			self.clear_cache()
			hide_busy_dialog()
			ok_dialog(text=ls(32732) % 'TorBox')
			return True
		interval = 5
		line = '%s[CR]%s[CR]%s'
		line1 = '%s...' % (ls(32732) % 'TorBox')
		line2 = transfer_info.get('name', 'TorBox')
		line3 = transfer_info.get('download_state') or transfer_info.get('state') or ''
		progressDialog = progress_dialog(ls(32733), icon)
		progressDialog.update(line % (line1, line2, line3), 0)
		while str(transfer_info.get('download_finished', False)).lower() != 'true':
			sleep(1000 * interval)
			transfer_info = self.list_transfer(transfer_id)
			line2 = transfer_info.get('name', line2)
			line3 = transfer_info.get('download_state') or transfer_info.get('state') or line3
			progress = int(float(transfer_info.get('download_progress', 0) or 0))
			progressDialog.update(line % (line1, line2, line3), progress)
			if monitor.abortRequested() == True:
				return
			try:
				if progressDialog.iscanceled():
					return _return_failed(32736, cancelled=True)
			except Exception:
				pass
			if transfer_info.get('download_state') in ('error', 'failed'):
				return _return_failed()
		sleep(1000 * interval)
		try:
			progressDialog.close()
		except Exception:
			pass
		hide_busy_dialog()
		return True

	def get_hosts(self):
		string = 'fen_tb_valid_hosts'
		url = 'webdl/hosters'
		hosts_dict = {'TorBox': []}
		hosts = []
		try:
			result = cache_object(self._get, string, url, False, 168)
			data = self._parse_data(result)
			if isinstance(data, list):
				for item in data:
					if isinstance(item, dict):
						domains = item.get('domains') or item.get('domain') or []
						if isinstance(domains, str):
							domains = [domains]
						hosts.extend(domains)
			hosts_dict['TorBox'] = list(set(hosts))
		except:
			pass
		return hosts_dict

	def clear_cache(self, clear_hashes=True):
		try:
			if not path_exists(maincache_db):
				return True
			from caches.debrid_cache import debrid_cache
			dbcon = database.connect(maincache_db)
			dbcur = dbcon.cursor()
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id=?""", ('fen_tb_user_cloud',))
				clear_property('fen_tb_user_cloud')
				dbcon.commit()
			except:
				pass
			try:
				dbcur.execute("""DELETE FROM maincache WHERE id=?""", ('fen_tb_valid_hosts',))
				clear_property('fen_tb_valid_hosts')
				dbcon.commit()
			except:
				pass
			if clear_hashes:
				try:
					debrid_cache.clear_debrid_results('tb')
				except:
					pass
			try:
				dbcon.close()
			except:
				pass
		except:
			return False
		return True
